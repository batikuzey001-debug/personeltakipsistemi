# /README.md
# Personel Takip Sistemi (Monorepo)
Bu repo; **admin panel** ve **API** uygulamalarını tek yerde toplar. İlk hedef: Super Admin için login + dashboard (iskelet).
