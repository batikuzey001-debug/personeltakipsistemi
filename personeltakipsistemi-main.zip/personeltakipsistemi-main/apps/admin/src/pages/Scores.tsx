export default function Scores() {
  return (
    <div>
      <h1>Skorlar</h1>
      <p>Dönem bazlı skor listesi / import (placeholder).</p>
    </div>
  );
}
