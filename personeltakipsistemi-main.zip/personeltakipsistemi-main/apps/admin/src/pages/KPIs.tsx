export default function KPIs() {
  return (
    <div>
      <h1>KPI'lar</h1>
      <p>KPI tanım/ağırlık/target ekranı (placeholder).</p>
    </div>
  );
}
