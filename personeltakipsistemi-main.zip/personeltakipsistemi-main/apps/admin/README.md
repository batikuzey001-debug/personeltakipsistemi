# Admin Panel (Super Admin – İskelet)

Bu uygulama **Super Admin** için giriş (login) ve dashboard ekranlarını içerir.
Şu an sadece iskelet kurulum yapılmaktadır.
