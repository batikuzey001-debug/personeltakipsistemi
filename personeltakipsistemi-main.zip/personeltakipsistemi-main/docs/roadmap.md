# Roadmap (Sprint Planı)

## Sprint-1
- Admin panel iskeleti
- Login ekranı (mock)
- Dashboard ekranı (placeholder)

## Sprint-2
- Personel listesi ekranı
- RBAC görünürlük (super_admin)

## Sprint-3
- API kimlik doğrulama (JWT)
- Paneli API’ye bağlama
